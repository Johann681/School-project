const express = require("express");
const router = express.Router();
const xss = require("xss");
const Attendance = require("../models/Attendance");
const ClassModel = require("../models/Class");
const Course = require("../models/Course");
const User = require("../models/User");
const { requireAuth, requireRole } = require("../middleware/auth");
const { auditLogger } = require("../middleware/auditLog");

const sanitize = (value) => {
  if (typeof value !== "string") return "";
  return xss(value.trim());
};

router.use(requireAuth, requireRole("TEACHER"));

router.post("/record", async (req, res) => {
  try {
    const classId = sanitize(req.body.classId);
    const courseId = sanitize(req.body.courseId);
    const period = sanitize(req.body.period);
    const academicSession = sanitize(req.body.academicSession);
    const term = sanitize(req.body.term);
    const records = Array.isArray(req.body.records) ? req.body.records : [];

    if (!classId || !period || !academicSession || !term || records.length === 0) {
      return res.status(400).json({ success: false, message: "All attendance fields are required." });
    }

    const attendance = await Attendance.create({
      classId,
      teacherId: req.user._id,
      courseId: courseId || undefined,
      period,
      academicSession,
      term,
      records: records.map((item) => ({
        studentId: item.studentId,
        status: item.status,
      })),
    });

    await auditLogger(req, "RECORD_ATTENDANCE", {
      classId,
      courseId,
      period,
      academicSession,
      term,
      recordsCount: records.length,
    });

    return res.status(201).json({ success: true, attendance });
  } catch (err) {
    console.error("Attendance record error:", err);
    return res.status(500).json({ success: false, message: "Unable to record attendance." });
  }
});

router.post("/scan", async (req, res) => {
  try {
    const qrToken = sanitize(req.body.qrToken);

    if (!qrToken) {
      return res.status(400).json({ success: false, message: "Attendance token is required." });
    }

    // In the next pass we can verify signed QR tokens and link them to student/class records.
    return res.status(200).json({ success: true, message: "Attendance token accepted. Verification workflow pending." });
  } catch (err) {
    console.error("Attendance scan error:", err);
    return res.status(500).json({ success: false, message: "Unable to process attendance scan." });
  }
});

module.exports = router;
