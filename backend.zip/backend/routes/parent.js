const express = require("express");
const router = express.Router();
const Announcement = require("../models/Announcement");
const User = require("../models/User");
const Attendance = require("../models/Attendance");
const Course = require("../models/Course");
const { requireAuth, requireRole } = require("../middleware/auth");

router.use(requireAuth, requireRole("PARENT"));

router.get("/children/results", async (req, res) => {
  try {
    const parent = await User.findById(req.user._id).populate({
      path: "linkedStudents",
      select: "fullName email studentClass",
      populate: {
        path: "studentClass",
        select: "name academicSession",
      },
    });

    if (!parent) {
      return res.status(404).json({ success: false, message: "Parent profile not found." });
    }

    const children = await Promise.all(
      parent.linkedStudents.map(async (student) => {
        const courses = await Course.find({ targetClass: student.studentClass })
          .select("title teachers targetClass")
          .populate("teachers", "fullName");

        const recentAttendance = await Attendance.find({ "records.studentId": student._id })
          .sort({ timestamp: -1 })
          .limit(10)
          .lean();

        return {
          studentId: student._id,
          studentName: student.fullName,
          studentEmail: student.email,
          studentClass: student.studentClass?.name,
          academicSession: student.studentClass?.academicSession,
          courses: courses.map((course) => ({
            _id: course._id,
            title: course.title,
            teachers: course.teachers.map((t) => t.fullName),
          })),
          attendance: recentAttendance.map((attendance) => ({
            date: attendance.timestamp,
            classId: attendance.classId,
            courseId: attendance.courseId,
            period: attendance.period,
            records: attendance.records.filter((record) => record.studentId.toString() === student._id.toString()),
          })),
        };
      })
    );

    return res.json({ success: true, children });
  } catch (err) {
    console.error("Parent children results error:", err);
    return res.status(500).json({ success: false, message: "Unable to retrieve linked children's results." });
  }
});

router.get("/announcements", async (req, res) => {
  try {
    const announcements = await Announcement.find({
      $or: [
        { targetAudience: "ALL" },
        { targetAudience: "PARENTS" },
      ],
    })
      .sort({ createdAt: -1 })
      .populate("author", "fullName role")
      .lean();

    return res.json({ success: true, announcements });
  } catch (err) {
    console.error("Parent announcements error:", err);
    return res.status(500).json({ success: false, message: "Unable to fetch announcements." });
  }
});

module.exports = router;
